@echo off
title GG.PROS Fortnite Tweak Pack Installer
color 1f

echo ===============================================
echo           GG.PROS FORTNITE TWEAK PACK
echo ===============================================
echo.
echo Boost FPS ^| Reduce Input Lag ^| Optimize Fortnite
echo Chapter 7 Competitive Ready
echo.
echo ===============================================
echo.

set /p pass=Enter Password to Continue: 

if /I "%pass%"=="lunar77" (
    echo.
    echo Password Accepted!
    echo Starting Tweak Pack...
    timeout /t 2 >nul
) else (
    echo.
    echo Incorrect Password!
    timeout /t 2 >nul
    exit
)

echo.
echo Preparing tweaks...
timeout /t 2 >nul

echo Applying performance optimizations...
timeout /t 2 >nul

echo Finalizing setup...
timeout /t 2 >nul

echo.
echo ===============================================
echo   GG.PROS Fortnite Tweak Pack Ready!
echo ===============================================
echo.
echo Enjoy smoother gameplay!
pause
exit